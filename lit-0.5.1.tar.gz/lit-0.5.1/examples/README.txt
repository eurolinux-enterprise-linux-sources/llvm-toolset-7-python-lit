==============
 lit Examples
==============

This directory contains examples of 'lit' test suite configurations. The test
suites they define can be run with 'lit examples/example-name', for more details
see the README in each example.
